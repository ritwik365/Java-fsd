

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/connections")
public class connections extends HttpServlet 
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
	    private static final String JDBC_USERNAME = "username";
	    private static final String JDBC_PASSWORD = "password";

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        Connection connection = null;
	        Statement statement = null;
	        ResultSet resultSet = null;
	        
	        try {
	            // Initialize JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            // Create a connection
	            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
	            
	            // Create a statement
	            statement = connection.createStatement();
	            
	            // Add data to the table
	            String insertQuery = "INSERT INTO mytable (name, age) VALUES ('John', 25)";
	            statement.executeUpdate(insertQuery);
	            
	            // Retrieve data from the table
	            String selectQuery = "SELECT * FROM mytable";
	            resultSet = statement.executeQuery(selectQuery);
	            
	            // Process the result set
	            while (resultSet.next()) {
	                int id = resultSet.getInt("id");
	                String name = resultSet.getString("name");
	                int age = resultSet.getInt("age");
	                
	                // Do something with the retrieved data
	                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            if (resultSet != null) {
	                try {
	                    resultSet.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            
	            if (statement != null) {
	                try {
	                    statement.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            
	            if (connection != null) {
	                try {
	                    connection.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }

}
