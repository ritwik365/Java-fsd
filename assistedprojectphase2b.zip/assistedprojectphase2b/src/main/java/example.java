

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/example")
public class example extends HttpServlet 
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
	    private static final String JDBC_USERNAME = "username";
	    private static final String JDBC_PASSWORD = "password";

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String name = request.getParameter("name");
	        int age = Integer.parseInt(request.getParameter("age"));
	        
	        Connection connection = null;
	        Statement statement = null;
	        
	        try {
	            // Initialize JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            // Create a connection
	            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
	            
	            // Create a statement
	            statement = connection.createStatement();
	            
	            // Perform the operation based on the form submission
	            if (request.getParameter("insert") != null) {
	                // Insert a new record
	                String insertQuery = "INSERT INTO mytable (name, age) VALUES ('" + name + "', " + age + ")";
	                statement.executeUpdate(insertQuery);
	                
	                response.getWriter().println("Record inserted successfully.");
	            } else if (request.getParameter("update") != null) {
	                // Update an existing record
	                String updateQuery = "UPDATE mytable SET age = " + age + " WHERE name = '" + name + "'";
	                int rowsAffected = statement.executeUpdate(updateQuery);
	                
	                if (rowsAffected > 0) {
	                    response.getWriter().println("Record updated successfully.");
	                } else {
	                    response.getWriter().println("No record found to update.");
	                }
	            } else if (request.getParameter("delete") != null) {
	                // Delete a record
	                String deleteQuery = "DELETE FROM mytable WHERE name = '" + name + "'";
	                int rowsAffected = statement.executeUpdate(deleteQuery);
	                
	                if (rowsAffected > 0) {
	                    response.getWriter().println("Record deleted successfully.");
	                } else {
	                    response.getWriter().println("No record found to delete.");
	                }
	            }
	            
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            if (statement != null) {
	                try {
	                    statement.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            
	            if (connection != null) {
	                try {
	                    connection.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	}

}
