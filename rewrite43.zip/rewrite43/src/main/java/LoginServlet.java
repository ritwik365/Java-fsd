

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginServlet extends HttpServlet 
{
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String username = request.getParameter("username");
	        String password = request.getParameter("password");

	        // Perform authentication logic here
	        boolean isAuthenticated = authenticate(username, password);

	        if (isAuthenticated) 
	        {
	            // Store the username in a session attribute
	            request.getSession().setAttribute("username", username);

	            response.sendRedirect("/welcome");
	        }
	        else 
	        {
	            response.getWriter().println("Login failed. Please try again.");
	        }
	    }

	    private boolean authenticate(String username, String password) {
	        // Perform authentication logic here
	        // Return true if authentication is successful, false otherwise
	        return username.equals("admin") && password.equals("password");

}

}
