package assistedproject16;

import java.util.Scanner;

public class ExceptionHandlingDemo 
{

	public static void main(String[] args) 
	{
		Scanner m = new Scanner(System.in);
        System.out.println("Enter two numbers:");
        int num1 = m.nextInt();
        int num2 = m.nextInt();

        try 
        {
            int result = divide(num1, num2);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) 
        {
            System.out.println("ArithmeticException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        } 
        finally 
        {
            System.out.println("Finally block executed.");
        }
    }

    public static int divide(int num1, int num2) {
        return num1 / num2;

	}

}
