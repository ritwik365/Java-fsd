package assistedproject11;

class MyThread extends Thread {
    public void run() {
        System.out.println("Thread is running by extending the Thread class");
    }
}

// Runnable interface implementation
class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread is running by implementing the Runnable interface");
    }
}
public class ThreadCreationExample 
{

	public static void main(String[] args) 
	{
		
		 MyThread thread1 = new MyThread();
	        thread1.start();

	        // Creating thread by implementing the Runnable interface
	        Thread thread2 = new Thread(new MyRunnable());
	        thread2.start();
	}

}
