package assistedproject17;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileOperationsDemo 
{

	public static void main(String[] args) 
	{
		try {
            createFile();
            readFile();
            updateFile();
            deleteFile();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IOException occurred: " + e.getMessage());
        }
    }

    public static void createFile() throws IOException {
        File file = new File("myfile.txt");

        if (file.createNewFile()) {
            System.out.println("File created: " + file.getName());
        } else {
            System.out.println("File already exists.");
        }
    }

    public static void readFile() throws FileNotFoundException {
        File file = new File("myfile.txt");
        Scanner m = new Scanner(file);

        System.out.println("File content:");
        while (m .hasNextLine()) {
            String line = m .nextLine();
            System.out.println(line);
        }

        m .close();
    }

    public static void updateFile() throws IOException {
        File file = new File("myfile.txt");
        FileWriter writer = new FileWriter(file, true);

        writer.write("This line is appended to the file.");
        writer.close();

        System.out.println("File updated successfully.");
    }

    public static void deleteFile() {
        File file = new File("myfile.txt");

        if (file.delete()) {
            System.out.println("File deleted: " + file.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }

	}

}
