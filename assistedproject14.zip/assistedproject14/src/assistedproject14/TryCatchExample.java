package assistedproject14;

public class TryCatchExample {

	public static void main(String[] args) 
	{
		int[] numbers = { 1, 2, 3, 4, 5 };
        int index = 5;

        try 
        {
            int result = numbers[index];
            System.out.println("The element at index " + index + " is: " + result);
        } 
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Error: Index is out of bounds!");
        }

	}

}
