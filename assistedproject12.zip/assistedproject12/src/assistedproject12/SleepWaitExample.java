package assistedproject12;

public class SleepWaitExample 
{

	public static void main(String[] args) 
	{
		
		Thread sleepThread = new Thread(() -> {
            try {
                System.out.println("Sleeping for 2 seconds...");
                Thread.sleep(2000);
                System.out.println("Awake after sleep.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        Thread waitThread = new Thread(() -> {
            synchronized (SleepWaitExample.class) {
                try {
                    System.out.println("Waiting for 2 seconds...");
                    SleepWaitExample.class.wait(2000);
                    System.out.println("Resumed after wait.");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        sleepThread.start();
        waitThread.start();
	}

}
