/**
 * 
 */
/**
 * 
 */
module assistedproject12 {
}