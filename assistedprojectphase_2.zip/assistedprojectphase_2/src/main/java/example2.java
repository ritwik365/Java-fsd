

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/example2")
public class example2 extends HttpServlet 
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/";
	    private static final String JDBC_USERNAME = "username";
	    private static final String JDBC_PASSWORD = "password";

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String action = request.getParameter("action");
	        
	        Connection connection = null;
	        Statement statement = null;
	        
	        try {
	            // Initialize JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            // Create a connection
	            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
	            
	            // Create a statement
	            statement = connection.createStatement();
	            
	            // Perform the action based on the form submission
	            if (action.equals("create")) {
	                // Create a new database
	                String createQuery = "CREATE DATABASE mydatabase";
	                statement.executeUpdate(createQuery);
	                
	                response.getWriter().println("Database created successfully.");
	            } else if (action.equals("select")) {
	                // Select the database
	                String selectQuery = "USE mydatabase";
	                statement.executeUpdate(selectQuery);
	                
	                response.getWriter().println("Database selected successfully.");
	            } else if (action.equals("drop")) {
	                // Drop the database
	                String dropQuery = "DROP DATABASE mydatabase";
	                statement.executeUpdate(dropQuery);
	                
	                response.getWriter().println("Database dropped successfully.");
	            }
	            
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            if (statement != null) {
	                try {
	                    statement.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            
	            if (connection != null) {
	                try {
	                    connection.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	}

}
