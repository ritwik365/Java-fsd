package assistedproject19;

interface InterfaceA {
    default void commonMethod() {
        System.out.println("InterfaceA's commonMethod()");
    }
}

interface InterfaceB {
    default void commonMethod() {
        System.out.println("InterfaceB's commonMethod()");
    }
}

class MyClass implements InterfaceA, InterfaceB {
    @Override
    public void commonMethod() {
        InterfaceA.super.commonMethod();  // Explicitly call InterfaceA's commonMethod()
    }
}


public class DiamondProblemDemo 
{

	public static void main(String[] args) 
	{
		 MyClass myObj = new MyClass();
	        myObj.commonMethod();

	}

}
