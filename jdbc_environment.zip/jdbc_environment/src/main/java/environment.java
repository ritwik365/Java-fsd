

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





@WebServlet("/environment")
public class environment extends HttpServlet 
{
	  private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
	    private static final String JDBC_USERNAME = "username";
	    private static final String JDBC_PASSWORD = "password";

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        Connection connection = null;
	        
	        try {
	            // Initialize JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            // Create a connection
	            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
	            
	            // Use the connection for database operations
	            
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the connection
	            if (connection != null) {
	                try {
	                    connection.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }


}
