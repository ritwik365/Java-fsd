package assistedproject15;

import java.util.Scanner;


class DivisionException extends Exception 
{
 public DivisionException(String message)
 {
     super(message);
 }
}


public class ExceptionDemo 
{

	public static void main(String[] args) 
	{
		 Scanner m = new Scanner(System.in);
	        System.out.println("Enter two numbers:");
	        int num1 = m .nextInt();
	        int num2 = m.nextInt();

	        try {
	            int result = divide(num1, num2);
	            System.out.println("Result: " + result);
	        } catch (DivisionException e) {
	            System.out.println("Exception caught: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed.");
	        }
	    }

	    public static int divide(int num1, int num2) throws DivisionException {
	        try {
	            if (num2 == 0) {
	                throw new DivisionException("Cannot divide by zero.");
	            }
	            return num1 / num2;
	        } catch (ArithmeticException e) {
	            throw new DivisionException("Arithmetic exception occurred.");
	        }

	}

}
