package assistedproject18;

class BankAccount 
{
 private String accountNumber;
 private double balance;

 public BankAccount(String accountNumber, double balance) 
 {
     this.accountNumber = accountNumber;
     this.balance = balance;
 }

 public void deposit(double amount) 
 {
     balance += amount;
     System.out.println("Deposited " + amount + " units. New balance: " + balance);
 }

 public void withdraw(double amount) 
 {
     if (balance >= amount) 
     {
         balance -= amount;
         System.out.println("Withdrawn " + amount + " units. New balance: " + balance);
     } 
     else 
     {
         System.out.println("Insufficient funds. Current balance: " + balance);
     }
 }

 public double getBalance() 
 {
     return balance;
 }
}


class SavingsAccount extends BankAccount 
{
 private double interestRate;

 public SavingsAccount(String accountNumber, double balance, double interestRate) 
 {
     super(accountNumber, balance);
     this.interestRate = interestRate;
 }

 public void applyInterest() 
 {
     double interestAmount = getBalance() * interestRate;
     deposit(interestAmount);
     System.out.println("Interest applied. New balance: " + getBalance());
 }
}


class CheckingAccount extends BankAccount 
{
 private double overdraftLimit;

 public CheckingAccount(String accountNumber, double balance, double overdraftLimit) 
 {
     super(accountNumber, balance);
     this.overdraftLimit = overdraftLimit;
 }

 public void withdraw(double amount) 
 {
     if (getBalance() + overdraftLimit >= amount) 
     {
         super.withdraw(amount);
     } else {
         System.out.println("Insufficient funds. Current balance: " + getBalance());
     }
 }
}

public class BankingSystemDemo 
{

	public static void main(String[] args) 
	{
		
        BankAccount bankAccount = new BankAccount("BA001", 1000);
        SavingsAccount savingsAccount = new SavingsAccount("SA001", 2000, 0.05);
        CheckingAccount checkingAccount = new CheckingAccount("CA001", 3000, 500);

    
        bankAccount.deposit(500);
        bankAccount.withdraw(200);
        savingsAccount.deposit(1000);
        savingsAccount.applyInterest();
        checkingAccount.withdraw(4000);
        checkingAccount.withdraw(200);

      
        BankAccount account = new SavingsAccount("SA002", 1500, 0.03);
        account.deposit(300);
        account.withdraw(200);

	}

}
