

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/storeprocedure")
public class storeprocedure extends HttpServlet 
{
	
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	 private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
	    private static final String JDBC_USERNAME = "username";
	    private static final String JDBC_PASSWORD = "password";

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String name = request.getParameter("name");
	        int age = Integer.parseInt(request.getParameter("age"));
	        
	        Connection connection = null;
	        CallableStatement callableStatement = null;
	        
	        try {
	            // Initialize JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            // Create a connection
	            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
	            
	            // Prepare the call to the stored procedure
	            String call = "{CALL add_person(?, ?)}";
	            callableStatement = connection.prepareCall(call);
	            
	            // Set the input parameters
	            callableStatement.setString(1, name);
	            callableStatement.setInt(2, age);
	            
	            // Execute the stored procedure
	            callableStatement.executeUpdate();
	            
	            // Process the result or handle exceptions as needed
	            
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the resources
	            if (callableStatement != null) {
	                try {
	                    callableStatement.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	            
	            if (connection != null) {
	                try {
	                    connection.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
}
